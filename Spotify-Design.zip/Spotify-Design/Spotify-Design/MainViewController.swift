//
//  MainViewController.swift
//  Spotify-Design
//
//  Created by Rumeysa TAN on 2.05.2022.
//

import UIKit

class MainViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
