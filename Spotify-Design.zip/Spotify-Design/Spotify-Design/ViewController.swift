//
//  ViewController.swift
//  Spotify-Design
//
//  Created by Rumeysa TAN on 2.05.2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let searchBar = UISearchBar()
                    searchBar.sizeToFit()
                    searchBar.placeholder = "Search"
                    navigationItem.titleView = searchBar

                    if let textfield = searchBar.value(forKey: "searchField") as? UITextField {
                        textfield.textColor = UIColor.blue
                        if let backgroundview = textfield.subviews.first {
                            // Background color
                            backgroundview.backgroundColor = UIColor.white
                            // Rounded corner
                            backgroundview.layer.cornerRadius = 14;
                            backgroundview.clipsToBounds = true;
                        }
                    }
        
    }


}

