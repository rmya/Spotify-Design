//
//  MusicTypes.swift
//  Spotify-Design
//
//  Created by Rumeysa TAN on 3.05.2022.
//

import Foundation

class MusicTypes {
    var typeId : Int?
    var typeName : String?
    var mbgColor : String?
    var mImage : String?
    var isTopGenre : Bool?
    
    init (typeId:Int, typeName:String, mbgColor:String, mImage:String, isTopGenre:Bool){
        self.typeId = typeId
        self.typeName = typeName
        self.mbgColor = mbgColor
        self.mImage = mImage
        self.isTopGenre = isTopGenre
    }
}
