//
//  SearchViewController.swift
//  Spotify-Design
//
//  Created by Rumeysa TAN on 2.05.2022.
//

import UIKit

class SearchViewController: UIViewController {
    
    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet weak var topGenresCollectionView: UICollectionView!
    @IBOutlet weak var browseAllCollectionView: UICollectionView!
    
    var allMusicTypeList = [MusicTypes]()
    var topGenresList = [MusicTypes]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        searchBar.layer.borderColor = UIColor.black.cgColor
        searchBar.layer.borderWidth = 0.3
        searchBar.layer.cornerRadius = 8.0
        
        topGenresCollectionView.delegate = self
        topGenresCollectionView.dataSource = self
        
        browseAllCollectionView.delegate = self
        browseAllCollectionView.dataSource = self
        
        let m1 = MusicTypes(typeId: 1, typeName: "Rock", mbgColor: "rockColor", mImage: "rock", isTopGenre: true)
        let m2 = MusicTypes(typeId: 2, typeName: "Rap", mbgColor: "rapColor", mImage: "rap", isTopGenre: true)
        let m3 = MusicTypes(typeId: 3, typeName: "R&B", mbgColor: "r&bColor", mImage: "r&b", isTopGenre: true)
        let m4 = MusicTypes(typeId: 4, typeName: "Pop", mbgColor: "popColor", mImage: "pop", isTopGenre: true)
        let m5 = MusicTypes(typeId: 5, typeName: "Metal", mbgColor: "metalColor", mImage: "metal", isTopGenre: true)
        let m6 = MusicTypes(typeId: 6, typeName: "K-Pop", mbgColor: "kpopColor", mImage: "kpop", isTopGenre: true)
        let m7 = MusicTypes(typeId: 7, typeName: "Jazz", mbgColor: "jazzColor", mImage: "jazz", isTopGenre: true)
        let m8 = MusicTypes(typeId: 8, typeName: "Classic", mbgColor: "classicalColor", mImage: "classical", isTopGenre: true)
        let m9 = MusicTypes(typeId: 9, typeName: "Blues", mbgColor: "bluesColor", mImage: "blues", isTopGenre: true)
        let m10 = MusicTypes(typeId: 10, typeName: "Electronic", mbgColor: "electronicColor", mImage: "electronic", isTopGenre: false)
        let m11 = MusicTypes(typeId: 11, typeName: "Country", mbgColor: "countryColor", mImage: "country", isTopGenre: false)
        let m12 = MusicTypes(typeId: 12, typeName: "Charts", mbgColor: "chartsColor", mImage: "charts", isTopGenre: false)
        let m13 = MusicTypes(typeId: 13, typeName: "Discover", mbgColor: "discoverColor", mImage: "discover", isTopGenre: false)
        let m14 = MusicTypes(typeId: 14, typeName: "Made For You", mbgColor: "madeForYouColor", mImage: "madeForYou", isTopGenre: false)
        let m15 = MusicTypes(typeId: 15, typeName: "New Release", mbgColor: "newReleaseColor", mImage: "newRelease", isTopGenre: false)
        let m16 = MusicTypes(typeId: 16, typeName: "Podcast", mbgColor: "podcastColor", mImage: "podcast", isTopGenre: false)
        let m17 = MusicTypes(typeId: 17, typeName: "Radio", mbgColor: "radioColor", mImage: "radio", isTopGenre: false)
        let m18 = MusicTypes(typeId: 18, typeName: "Summer", mbgColor: "summerColor", mImage: "summer", isTopGenre: false)
        let m19 = MusicTypes(typeId: 19, typeName: "At home", mbgColor: "atHomeColor", mImage: "atHome", isTopGenre: false)
        let m20 = MusicTypes(typeId: 19, typeName: "Focus", mbgColor: "focusColor", mImage: "focus", isTopGenre: false)
        let m21 = MusicTypes(typeId: 19, typeName: "Gaming", mbgColor: "gamingColor", mImage: "gaming", isTopGenre: false)
        let m22 = MusicTypes(typeId: 19, typeName: "Workout", mbgColor: "workoutColor", mImage: "workout", isTopGenre: false)
        let m23 = MusicTypes(typeId: 19, typeName: "Mood", mbgColor: "moodColor", mImage: "mood", isTopGenre: false)
        allMusicTypeList.append(m19)
        allMusicTypeList.append(m3)
        allMusicTypeList.append(m12)
        allMusicTypeList.append(m14)
        allMusicTypeList.append(m15)
        allMusicTypeList.append(m16)
        allMusicTypeList.append(m9)
        allMusicTypeList.append(m20)
        allMusicTypeList.append(m21)
        allMusicTypeList.append(m22)
        allMusicTypeList.append(m23)
        allMusicTypeList.append(m1)
        allMusicTypeList.append(m2)
        allMusicTypeList.append(m13)
        allMusicTypeList.append(m4)
        allMusicTypeList.append(m5)
        allMusicTypeList.append(m6)
        allMusicTypeList.append(m7)
        allMusicTypeList.append(m8)
        allMusicTypeList.append(m10)
        allMusicTypeList.append(m11)
        allMusicTypeList.append(m12)
        allMusicTypeList.append(m13)
        allMusicTypeList.append(m14)
        allMusicTypeList.append(m15)
        allMusicTypeList.append(m16)
        allMusicTypeList.append(m17)
        allMusicTypeList.append(m18)
        
        
        let g1 = MusicTypes(typeId: 1, typeName: "Rock", mbgColor: "rockColor", mImage: "rock", isTopGenre: true)
        let g2 = MusicTypes(typeId: 2, typeName: "Rap", mbgColor: "rapColor", mImage: "rap", isTopGenre: true)
        let g3 = MusicTypes(typeId: 3, typeName: "R&B", mbgColor: "r&bColor", mImage: "r&b", isTopGenre: true)
        let g4 = MusicTypes(typeId: 4, typeName: "Pop", mbgColor: "popColor", mImage: "pop", isTopGenre: true)
        let g5 = MusicTypes(typeId: 5, typeName: "Metal", mbgColor: "metalColor", mImage: "metal", isTopGenre: true)
        let g6 = MusicTypes(typeId: 6, typeName: "K-Pop", mbgColor: "kpopColor", mImage: "kpop", isTopGenre: true)
        let g7 = MusicTypes(typeId: 7, typeName: "Jazz", mbgColor: "jazzColor", mImage: "jazz", isTopGenre: true)
        let g8 = MusicTypes(typeId: 8, typeName: "Classical", mbgColor: "classicalColor", mImage: "classical", isTopGenre: true)
        let g9 = MusicTypes(typeId: 9, typeName: "Blues", mbgColor: "bluesColor", mImage: "blues", isTopGenre: true)
        topGenresList.append(g1)
        topGenresList.append(g2)
        topGenresList.append(g3)
        topGenresList.append(g4)
        topGenresList.append(g5)
        topGenresList.append(g6)
        topGenresList.append(g7)
        topGenresList.append(g8)
        topGenresList.append(g9)
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .horizontal
        layout.collectionView?.isPagingEnabled = true
        layout.sectionInset = UIEdgeInsets(top: 10, left: 10, bottom: 10, right: 10)
        layout.minimumLineSpacing = 10
        layout.minimumInteritemSpacing = 10
        let witdh = topGenresCollectionView.frame.size.width
        let cellWitdh = (witdh - 30) / 2
        layout.itemSize = CGSize(width: cellWitdh, height: 100)
        topGenresCollectionView.collectionViewLayout = layout
        
        let mlayout = UICollectionViewFlowLayout()
        mlayout.sectionInset = UIEdgeInsets(top: 5, left: 5, bottom: 5, right: 5)
        mlayout.minimumInteritemSpacing = 15
        mlayout.minimumLineSpacing = 15
        let mwitdh = browseAllCollectionView.frame.size.width
        let mCellWitdh = (mwitdh - 30) / 2
        mlayout.itemSize = CGSize(width: mCellWitdh, height: 100)
        browseAllCollectionView.collectionViewLayout = mlayout

        
    }

}

extension SearchViewController : UICollectionViewDelegate, UICollectionViewDataSource {
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == topGenresCollectionView {
            return topGenresList.count
        }
            return allMusicTypeList.count

    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == topGenresCollectionView {
            
            let topGenre = topGenresList[indexPath.row]
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "topGenres", for: indexPath) as! SearchTopGenresCollectionViewCell
            
            cell.genreNameLabel.text = topGenre.typeName!
            cell.genreImage.image = UIImage(named: topGenre.mImage!)
            cell.genresView.backgroundColor = UIColor(named: topGenre.mbgColor!)
            
            cell.genresView.layer.borderColor = UIColor.black.cgColor
            cell.genresView.layer.borderWidth = 0.3
            cell.layer.cornerRadius = 8.0

            return cell
        }
        
        let allMusic = allMusicTypeList[indexPath.row]
        let mcell = collectionView.dequeueReusableCell(withReuseIdentifier: "browseAll", for: indexPath) as! SearchBrowseAllCollectionViewCell
        
        mcell.browseAllLabel.text = allMusic.typeName!
        mcell.browseAllimage.image = UIImage(named: allMusic.mImage!)
        mcell.browseAllContentView.backgroundColor = UIColor(named: allMusic.mbgColor!)
        
        mcell.browseAllContentView.layer.borderColor = UIColor.black.cgColor
        mcell.browseAllContentView.layer.borderWidth = 0.3
        mcell.layer.cornerRadius = 8.0
        
        return mcell

    }
}

