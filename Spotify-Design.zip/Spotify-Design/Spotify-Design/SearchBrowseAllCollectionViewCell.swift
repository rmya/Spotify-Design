//
//  SearchBrowseAllCollectionViewCell.swift
//  Spotify-Design
//
//  Created by Rumeysa TAN on 4.05.2022.
//

import UIKit

class SearchBrowseAllCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var browseAllLabel: UILabel!
    @IBOutlet weak var browseAllContentView: UIView!
    @IBOutlet weak var browseAllimage: UIImageView!
}
