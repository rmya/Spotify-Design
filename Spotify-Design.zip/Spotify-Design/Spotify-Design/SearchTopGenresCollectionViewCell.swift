//
//  SearchTopGenresCollectionViewCell.swift
//  Spotify-Design
//
//  Created by Rumeysa TAN on 3.05.2022.
//

import UIKit

class SearchTopGenresCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var genresView: UIView!
    @IBOutlet weak var genreNameLabel: UILabel!
    @IBOutlet weak var genreImage: UIImageView!
    
    
}
